ndays=cumsum(c(0,31,28,31,30,31,30,31,31,30,31,30,31))

xaika=function(b) {
 Day = ndays[b$Month] + b$Day
 # Clock times represented in one integer with 6 digits (2 hour, 2 minute, 2 second), convert to hours
 foo = (b$Time + round(b$Longitude/360*24)*10000) %% 240000
 seconds = (foo %% 100)
 minutes = (foo - seconds) %% 10000
 hours = foo - seconds - minutes

 Time = (hours + (minutes + seconds*100/60)*100/60)/10000
 list(xday=Day/365,xtime=Time/24)
}

xaikaOLD=function(b) {
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000
 list(xday=Day/365,xtime=Time/24)
}

okaika=function(b) {
 okday = sort(unique(ndays[b$Month] + b$Day))
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000
 oktime = sort(unique(Time))
 list(day=okday,time=oktime)
}

omamodel1 = function(y, b) {
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)

 z = lm(y ~ x1+x2+x3+x4+x5+x6+x7+x8)
}

omapredict1=function(z,xday,xtime) {
 footime=rep(xtime[1],length(xday))
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*footime)
 x6 = sin(4*pi*footime)
 x7 = cos(2*pi*footime)
 x8 = cos(4*pi*footime)
 yday=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 fooday=rep(xday[1],length(xtime))
 x1 = sin(2*pi*fooday)
 x2 = sin(4*pi*fooday)
 x3 = cos(2*pi*fooday)
 x4 = cos(4*pi*fooday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 ytime=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 # offset correction, take maximum of yday and ytime (ok because linear model)
 yday2 = yday + max(ytime) - ytime[1]
 ytime2 = ytime + max(yday) - yday[1]
 list(yday=yday2,ytime=ytime2)
}

omapredict1b=function(z,xday,xtime) {
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 y=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
}

omamodel2 = function(y, b) {
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)

 z = glm(y ~ x1+x2+x3+x4+x5+x6+x7+x8, family=poisson)
}

omapredict2=function(z,xday,xtime) {
 footime=rep(xtime[1],length(xday))
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*footime)
 x6 = sin(4*pi*footime)
 x7 = cos(2*pi*footime)
 x8 = cos(4*pi*footime)
 yday=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 fooday=rep(xday[1],length(xtime))
 x1 = sin(2*pi*fooday)
 x2 = sin(4*pi*fooday)
 x3 = cos(2*pi*fooday)
 x4 = cos(4*pi*fooday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 ytime=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 # offset correction, take maximum of yday and ytime
 dmaxi=which.max(yday)
 tmaxi=which.max(ytime)
 footime=rep(xtime[tmaxi],length(xday))
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*footime)
 x6 = sin(4*pi*footime)
 x7 = cos(2*pi*footime)
 x8 = cos(4*pi*footime)
 yday=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8),type="response")
 fooday=rep(xday[dmaxi],length(xtime))
 x1 = sin(2*pi*fooday)
 x2 = sin(4*pi*fooday)
 x3 = cos(2*pi*fooday)
 x4 = cos(4*pi*fooday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 ytime=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8),type="response")
 list(yday=yday,ytime=ytime)
}

omapredict2b=function(z,xday,xtime) {
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 y=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8),type="response")
}

all.omamodel1 = function(y, b) {
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 lat=b$Latitude/90

 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict1=function(z,xday,xtime, lat) {
 footime=rep(xtime[1],length(xday))
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*footime); x51 = lat*sin(2*pi*footime); x52 = lat^2 * sin(2*pi*footime)
 x60 = sin(4*pi*footime); x61 = lat*sin(4*pi*footime); x62 = lat^2 * sin(4*pi*footime)
 x70 = cos(2*pi*footime); x71 = lat*cos(2*pi*footime); x72 = lat^2 * cos(2*pi*footime)
 x80 = cos(4*pi*footime); x81 = lat*cos(4*pi*footime); x82 = lat^2 * cos(4*pi*footime)
 yday=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 fooday=rep(xday[1],length(xtime))
 x10 = sin(2*pi*fooday); x11 = lat*sin(2*pi*fooday); x12 = lat^2 * sin(2*pi*fooday)
 x20 = sin(4*pi*fooday); x21 = lat*sin(4*pi*fooday); x22 = lat^2 * sin(4*pi*fooday)
 x30 = cos(2*pi*fooday); x31 = lat*cos(2*pi*fooday); x32 = lat^2 * cos(2*pi*fooday)
 x40 = cos(4*pi*fooday); x41 = lat*cos(4*pi*fooday); x42 = lat^2 * cos(4*pi*fooday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 ytime=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 # offset correction, take maximum of yday and ytime (ok because linear model)
 yday2 = yday + max(ytime) - ytime[1]
 ytime2 = ytime + max(yday) - yday[1]
 list(yday=yday2,ytime=ytime2)
}

all.omapredict1b=function(z,xday,xtime, lat) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

all.omamodel2 = function(y, b) {
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 lat=b$Latitude/90

 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = glm(y ~ x01+x02+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82, family=poisson)
}

all.omapredict2=function(z,xday,xtime, lat) {
 footime=rep(xtime[1],length(xday))
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*footime); x51 = lat*sin(2*pi*footime); x52 = lat^2 * sin(2*pi*footime)
 x60 = sin(4*pi*footime); x61 = lat*sin(4*pi*footime); x62 = lat^2 * sin(4*pi*footime)
 x70 = cos(2*pi*footime); x71 = lat*cos(2*pi*footime); x72 = lat^2 * cos(2*pi*footime)
 x80 = cos(4*pi*footime); x81 = lat*cos(4*pi*footime); x82 = lat^2 * cos(4*pi*footime)
 yday=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 fooday=rep(xday[1],length(xtime))
 x10 = sin(2*pi*fooday); x11 = lat*sin(2*pi*fooday); x12 = lat^2 * sin(2*pi*fooday)
 x20 = sin(4*pi*fooday); x21 = lat*sin(4*pi*fooday); x22 = lat^2 * sin(4*pi*fooday)
 x30 = cos(2*pi*fooday); x31 = lat*cos(2*pi*fooday); x32 = lat^2 * cos(2*pi*fooday)
 x40 = cos(4*pi*fooday); x41 = lat*cos(4*pi*fooday); x42 = lat^2 * cos(4*pi*fooday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 ytime=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 # offset correction, take maximum of yday and ytime
 dmaxi=which.max(yday)
 tmaxi=which.max(ytime)
 footime=rep(xtime[tmaxi],length(xday))
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*footime); x51 = lat*sin(2*pi*footime); x52 = lat^2 * sin(2*pi*footime)
 x60 = sin(4*pi*footime); x61 = lat*sin(4*pi*footime); x62 = lat^2 * sin(4*pi*footime)
 x70 = cos(2*pi*footime); x71 = lat*cos(2*pi*footime); x72 = lat^2 * cos(2*pi*footime)
 x80 = cos(4*pi*footime); x81 = lat*cos(4*pi*footime); x82 = lat^2 * cos(4*pi*footime)
 yday=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82), type="response")
 fooday=rep(xday[dmaxi],length(xtime))
 x10 = sin(2*pi*fooday); x11 = lat*sin(2*pi*fooday); x12 = lat^2 * sin(2*pi*fooday)
 x20 = sin(4*pi*fooday); x21 = lat*sin(4*pi*fooday); x22 = lat^2 * sin(4*pi*fooday)
 x30 = cos(2*pi*fooday); x31 = lat*cos(2*pi*fooday); x32 = lat^2 * cos(2*pi*fooday)
 x40 = cos(4*pi*fooday); x41 = lat*cos(4*pi*fooday); x42 = lat^2 * cos(4*pi*fooday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 ytime=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82), type="response")
 list(yday=yday,ytime=ytime)
}

all.omapredict2b=function(z,xday,xtime, lat) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82), type="response")
}

all.omamodel3 = function(y, b, h) {
 # h is extra covariate in the model
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 lat=b$Latitude/90

 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+h+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict3b=function(z,xday,xtime, lat, h) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,h,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

all.omamodel32 = function(y, b, h) {
 # h is extra covariate in the model
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 lat=b$Latitude/90
 h2=h^2
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+h+h2+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict32b=function(z,xday,xtime, lat, h) {
 x01 = lat; x02 = lat^2
 h2 = h^2   
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,h,h2,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

all.omamodel4 = function(y, b, c1, c2, c3, c4) {
 # c1-4 are extra covariates in the model
 Day = ndays[b$Month] + b$Day
 # kellonajat esitetty 6 digitillä (2 tunneille, 2 minuuteille ja 2 sekunneille), muutetaan ne tunneiksi
 # huom. jos ei tasatunteja niin muuta minuutit 0000...6000 -> 0000...10000
 Time= ((b$Time + round(b$Longitude/360*24)*10000) %% 240000)/10000 

 xday = Day/365
 xtime = Time/24

 lat=b$Latitude/90
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+c1+c2+c3+c4+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict4b=function(z,xday,xtime, lat, c1, c2, c3, c4) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,c1,c2,c3,c4,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

repplot1 = function(siteid, yind) {
 i=which(a$Site==siteid)
 b=a[i,]
 print(table(b$AudioMoth,b$Month))

 ams=unique(b$AudioMoth)
 nams=length(ams)

 xday=seq(1,365)/365
 xtime=seq(0,23)/24

 ydays = matrix(0,nams,365)
 ytimes = matrix(0,nams,24)

 for (j in 1:nams) {
  i=which(b$AudioMoth == ams[j])
  bb=b[i,]
  z=omamodel1(bb[,yind], bb)
  f=omapredict1(z,xday,xtime)
  ydays[j,]=f$yday
  ytimes[j,]=f$ytime
 }

 foo=c(range(ytimes),range(ydays))
 yl=range(foo)
 par(mfrow=c(1,2))
 matplot(0:23,t(ytimes),type="l",lty=1,lwd=1,xlab="Time",ylab="",ylim=yl,main=colnames(a)[yind]);grid()
 matplot(1:365,t(ydays),type="l",lty=1,lwd=1,xlab="Day",ylab="",ylim=yl,main=colnames(a)[yind]);grid()
}

repplot2 = function(siteid, yind) {
 i=which(a$Site==siteid)
 b=a[i,]
 print(table(b$AudioMoth,b$Month))

 ams=unique(b$AudioMoth)
 nams=length(ams)

 xday=seq(1,365)/365
 xtime=seq(0,23)/24

 ydays = matrix(0,nams,365)
 ytimes = matrix(0,nams,24)

 for (j in 1:nams) {
  i=which(b$AudioMoth == ams[j])
  bb=b[i,]
  z=omamodel2(bb[,yind], bb)
  f=omapredict2(z,xday,xtime)
  ydays[j,]=f$yday
  ytimes[j,]=f$ytime
 }

 foo=c(range(ytimes),range(ydays))
 yl=range(foo)
 par(mfrow=c(1,2))
 matplot(0:23,t(ytimes),type="l",lty=1,lwd=1,xlab="Time",ylab="",ylim=yl,main=colnames(a)[yind]);grid()
 matplot(1:365,t(ydays),type="l",lty=1,lwd=1,xlab="Day",ylab="",ylim=yl,main=colnames(a)[yind]);grid()
}
