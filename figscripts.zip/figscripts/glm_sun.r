ndays=cumsum(c(0,31,28,31,30,31,30,31,31,30,31,30,31))

time2hours=function(clocktime) {
 # Clock times represented in one integer with 6 digits (2 hour, 2 minute, 2 second), convert to hours
 #foo = (clocktime + round(longitude/360*24)*10000) %% 240000
 foo = clocktime
 seconds = (foo %% 100)
 minutes = (foo - seconds) %% 10000
 hours = foo - seconds - minutes

 Time = (hours + (minutes + seconds*100/60)*100/60)/10000
}

maptime = function(localtime, sunrise, sunduration, morning=6,evening=18) {
 # map time between 0 and 24: 0..morning, morning..evening, evening..24 where morning..evening is daytime with sunlight

 # first change daytime between 0 and 24, where 0 is sunrise
 t1 = (localtime +24 -sunrise) %% 24
 if (t1 < sunduration) {
  # day, map to morning..evening
  w = t1/sunduration * (evening-morning) + morning
 } else {
  # night
  nightdur = 24-sunduration
  if (t1 < sunduration+nightdur/2) {
   # from evening to midnight, map to evening..24
   w = (t1-sunduration)/(nightdur/2) * (24-evening) + evening
  } else {
   # from midnight to morning, map to 0..morning
   w = (t1-sunduration-nightdur/2)/(nightdur/2) * morning
  }
 }
 w
}

suntimes = function(year,month,day, lat, lon) {
 # return sunrise and sunset in local time
 # library(suncalc)
 # suncalc is slow, so calculate values only for unique elements
 ymds = paste(year,month,day,lat,lon)
 u = unique(ymds)
 
 n=length(year)
 y=matrix(0,n,2)
 colnames(y) = c("sunrise","sunduration")
 n2 = length(u)
 for (i in 1:n2) {
  v = as.numeric(strsplit(u[i]," ")[[1]])
  mo=v[2]
  s = sprintf("%d-%02d-%02d",v[1],v[2],v[3])
  lat1=v[4]
  lon1=v[5]
  f = getSunlightTimes(date=as.Date(s),lat=lat1,lon=lon1,keep=c("sunrise","sunset"),tz="UTC")
  if (is.na(f$sunrise) | is.na(f$sunset)) {
   if (lat1 > 0) {
    if (mo > 3 & mo < 9) {
     # summer northern hemisphere
     t1=0; dur=24
    } else {
     # winter northern hemisphere
     t1=12; dur=0
    }
   } else {
    if (mo > 3 & mo < 9) {
     # winter southern hemisphere
     t1=12; dur=0
    } else {
     # summer southern hemisphere
     t1=0; dur=24
    }
   }
  } else {
   g = strsplit(as.character(f$sunrise)," ")[[1]][2]
   h = as.numeric(strsplit(g,":")[[1]])
   s1 = h[1] + h[2]/60 + h[3]/3600
   #g = strsplit(as.character(f$sunset)," ")[[1]][2]
   #h = as.numeric(strsplit(g,":")[[1]])
   #s2 = h[1] + h[2]/60 + h[3]/3600
   dur = as.numeric(difftime(f$sunset, f$sunrise, units="hours"))
   # unit can be hours, mins, or seconds...
   # change utc to local time
   t1=(s1 + lon1/360*24) %% 24
  }
  ii=which(ymds==u[i])
  foo=matrix(rep(c(t1,dur)), length(ii), 2, byrow=T)
  y[ii,]=foo
 }
 colnames(y) = c("sunrise","sunduration")
 y
}

time2suntime=function(b) {
 lat=b$Latitude
 lon=b$Longitude
 year=b$Year
 month=b$Month
 day=b$Day
 st = suntimes(year,month,day,lat,lon)
 clocktime = time2hours(b$Time)
 localtime = (clocktime + lon/360*24) %% 24
 suntime = localtime
 for (i in 1:length(localtime)) {suntime[i] = maptime(localtime[i], st[i,1], st[i,2])}
 suntime
}

xaika=function(Day,Time) {
 list(xday=Day/365,xtime=Time/24)
}

okaika=function(Day, Time) {
 okday = sort(unique(Day))
 oktime = sort(unique(Time))
 list(day=okday,time=oktime)
}

omamodel1 = function(y, Day, Time) {
 xday = Day/365
 xtime = Time/24

 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)

 z = lm(y ~ x1+x2+x3+x4+x5+x6+x7+x8)
}

omapredict1=function(z,xday,xtime) {
 footime=rep(xtime[1],length(xday))
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*footime)
 x6 = sin(4*pi*footime)
 x7 = cos(2*pi*footime)
 x8 = cos(4*pi*footime)
 yday=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 fooday=rep(xday[1],length(xtime))
 x1 = sin(2*pi*fooday)
 x2 = sin(4*pi*fooday)
 x3 = cos(2*pi*fooday)
 x4 = cos(4*pi*fooday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 ytime=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 # offset correction, take maximum of yday and ytime (ok because linear model)
 yday2 = yday + max(ytime) - ytime[1]
 ytime2 = ytime + max(yday) - yday[1]
 list(yday=yday2,ytime=ytime2)
}

omapredict1b=function(z,xday,xtime) {
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 y=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
}

omamodel2 = function(y, Day, Time) {
 xday = Day/365
 xtime = Time/24

 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)

 z = glm(y ~ x1+x2+x3+x4+x5+x6+x7+x8, family=poisson)
}

omapredict2=function(z,xday,xtime) {
 footime=rep(xtime[1],length(xday))
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*footime)
 x6 = sin(4*pi*footime)
 x7 = cos(2*pi*footime)
 x8 = cos(4*pi*footime)
 yday=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 fooday=rep(xday[1],length(xtime))
 x1 = sin(2*pi*fooday)
 x2 = sin(4*pi*fooday)
 x3 = cos(2*pi*fooday)
 x4 = cos(4*pi*fooday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 ytime=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8))
 # offset correction, take maximum of yday and ytime
 dmaxi=which.max(yday)
 tmaxi=which.max(ytime)
 footime=rep(xtime[tmaxi],length(xday))
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*footime)
 x6 = sin(4*pi*footime)
 x7 = cos(2*pi*footime)
 x8 = cos(4*pi*footime)
 yday=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8),type="response")
 fooday=rep(xday[dmaxi],length(xtime))
 x1 = sin(2*pi*fooday)
 x2 = sin(4*pi*fooday)
 x3 = cos(2*pi*fooday)
 x4 = cos(4*pi*fooday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 ytime=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8),type="response")
 list(yday=yday,ytime=ytime)
}

omapredict2b=function(z,xday,xtime) {
 x1 = sin(2*pi*xday)
 x2 = sin(4*pi*xday)
 x3 = cos(2*pi*xday)
 x4 = cos(4*pi*xday)
 x5 = sin(2*pi*xtime)
 x6 = sin(4*pi*xtime)
 x7 = cos(2*pi*xtime)
 x8 = cos(4*pi*xtime)
 y=predict(z,data.frame(x1,x2,x3,x4,x5,x6,x7,x8),type="response")
}

all.omamodel1 = function(y, Day, Time, Latitude) {
 xday = Day/365
 xtime = Time/24
 lat=Latitude/90

 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict1=function(z,xday,xtime, lat) {
 footime=rep(xtime[1],length(xday))
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*footime); x51 = lat*sin(2*pi*footime); x52 = lat^2 * sin(2*pi*footime)
 x60 = sin(4*pi*footime); x61 = lat*sin(4*pi*footime); x62 = lat^2 * sin(4*pi*footime)
 x70 = cos(2*pi*footime); x71 = lat*cos(2*pi*footime); x72 = lat^2 * cos(2*pi*footime)
 x80 = cos(4*pi*footime); x81 = lat*cos(4*pi*footime); x82 = lat^2 * cos(4*pi*footime)
 yday=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 fooday=rep(xday[1],length(xtime))
 x10 = sin(2*pi*fooday); x11 = lat*sin(2*pi*fooday); x12 = lat^2 * sin(2*pi*fooday)
 x20 = sin(4*pi*fooday); x21 = lat*sin(4*pi*fooday); x22 = lat^2 * sin(4*pi*fooday)
 x30 = cos(2*pi*fooday); x31 = lat*cos(2*pi*fooday); x32 = lat^2 * cos(2*pi*fooday)
 x40 = cos(4*pi*fooday); x41 = lat*cos(4*pi*fooday); x42 = lat^2 * cos(4*pi*fooday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 ytime=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 # offset correction, take maximum of yday and ytime (ok because linear model)
 yday2 = yday + max(ytime) - ytime[1]
 ytime2 = ytime + max(yday) - yday[1]
 list(yday=yday2,ytime=ytime2)
}

all.omapredict1b=function(z,xday,xtime, lat) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

all.omamodel2 = function(y, Day, Time, Latitude) {
 xday = Day/365
 xtime = Time/24
 lat=Latitude/90

 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = glm(y ~ x01+x02+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82, family=poisson)
}

all.omapredict2=function(z,xday,xtime, lat) {
 footime=rep(xtime[1],length(xday))
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*footime); x51 = lat*sin(2*pi*footime); x52 = lat^2 * sin(2*pi*footime)
 x60 = sin(4*pi*footime); x61 = lat*sin(4*pi*footime); x62 = lat^2 * sin(4*pi*footime)
 x70 = cos(2*pi*footime); x71 = lat*cos(2*pi*footime); x72 = lat^2 * cos(2*pi*footime)
 x80 = cos(4*pi*footime); x81 = lat*cos(4*pi*footime); x82 = lat^2 * cos(4*pi*footime)
 yday=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 fooday=rep(xday[1],length(xtime))
 x10 = sin(2*pi*fooday); x11 = lat*sin(2*pi*fooday); x12 = lat^2 * sin(2*pi*fooday)
 x20 = sin(4*pi*fooday); x21 = lat*sin(4*pi*fooday); x22 = lat^2 * sin(4*pi*fooday)
 x30 = cos(2*pi*fooday); x31 = lat*cos(2*pi*fooday); x32 = lat^2 * cos(2*pi*fooday)
 x40 = cos(4*pi*fooday); x41 = lat*cos(4*pi*fooday); x42 = lat^2 * cos(4*pi*fooday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 ytime=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
 # offset correction, take maximum of yday and ytime
 dmaxi=which.max(yday)
 tmaxi=which.max(ytime)
 footime=rep(xtime[tmaxi],length(xday))
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*footime); x51 = lat*sin(2*pi*footime); x52 = lat^2 * sin(2*pi*footime)
 x60 = sin(4*pi*footime); x61 = lat*sin(4*pi*footime); x62 = lat^2 * sin(4*pi*footime)
 x70 = cos(2*pi*footime); x71 = lat*cos(2*pi*footime); x72 = lat^2 * cos(2*pi*footime)
 x80 = cos(4*pi*footime); x81 = lat*cos(4*pi*footime); x82 = lat^2 * cos(4*pi*footime)
 yday=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82), type="response")
 fooday=rep(xday[dmaxi],length(xtime))
 x10 = sin(2*pi*fooday); x11 = lat*sin(2*pi*fooday); x12 = lat^2 * sin(2*pi*fooday)
 x20 = sin(4*pi*fooday); x21 = lat*sin(4*pi*fooday); x22 = lat^2 * sin(4*pi*fooday)
 x30 = cos(2*pi*fooday); x31 = lat*cos(2*pi*fooday); x32 = lat^2 * cos(2*pi*fooday)
 x40 = cos(4*pi*fooday); x41 = lat*cos(4*pi*fooday); x42 = lat^2 * cos(4*pi*fooday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 ytime=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82), type="response")
 list(yday=yday,ytime=ytime)
}

all.omapredict2b=function(z,xday,xtime, lat) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82), type="response")
}

all.omamodel3 = function(y, Day, Time, Latitude, h) {
 # h is extra covariate in the model
 xday = Day/365
 xtime = Time/24
 lat=Latitude/90

 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+h+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict3b=function(z,xday,xtime, lat, h) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,h,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

all.omamodel32 = function(y, Day, Time, Latitude, h) {
 # h is extra covariate in the model
 xday = Day/365
 xtime = Time/24
 lat=Latitude/90
 h2=h^2
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+h+h2+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict32b=function(z,xday,xtime, lat, h) {
 x01 = lat; x02 = lat^2
 h2 = h^2   
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,h,h2,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

all.omamodel4 = function(y, Day, Time, Latitude, c1, c2, c3, c4) {
 # c1-4 are extra covariates in the model
 xday = Day/365
 xtime = Time/24
 lat=Latitude/90
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)

 z = lm(y ~ x01+x02+c1+c2+c3+c4+x10+x11+x12+x20+x21+x22+x30+x31+x32+x40+x41+x42+x50+x51+x52+x60+x61+x62+x70+x71+x72+x80+x81+x82)
}

all.omapredict4b=function(z,xday,xtime, lat, c1, c2, c3, c4) {
 x01 = lat; x02 = lat^2
 x10 = sin(2*pi*xday); x11 = lat*sin(2*pi*xday); x12 = lat^2 * sin(2*pi*xday)
 x20 = sin(4*pi*xday); x21 = lat*sin(4*pi*xday); x22 = lat^2 * sin(4*pi*xday)
 x30 = cos(2*pi*xday); x31 = lat*cos(2*pi*xday); x32 = lat^2 * cos(2*pi*xday)
 x40 = cos(4*pi*xday); x41 = lat*cos(4*pi*xday); x42 = lat^2 * cos(4*pi*xday)
 x50 = sin(2*pi*xtime); x51 = lat*sin(2*pi*xtime); x52 = lat^2 * sin(2*pi*xtime)
 x60 = sin(4*pi*xtime); x61 = lat*sin(4*pi*xtime); x62 = lat^2 * sin(4*pi*xtime)
 x70 = cos(2*pi*xtime); x71 = lat*cos(2*pi*xtime); x72 = lat^2 * cos(2*pi*xtime)
 x80 = cos(4*pi*xtime); x81 = lat*cos(4*pi*xtime); x82 = lat^2 * cos(4*pi*xtime)
 y=predict(z,data.frame(x01,x02,c1,c2,c3,c4,x10,x11,x12,x20,x21,x22,x30,x31,x32,x40,x41,x42,x50,x51,x52,x60,x61,x62,x70,x71,x72,x80,x81,x82))
}

