#!/usr/bin/bash

source /data/lifeplan_analyze/venv/bin/activate

if [ $# -eq 0 ]
 then
  echo "usage: $0 datlistfile datdir"
  exit
fi

datlistfile=$1
datdir=$2

if [ ! -f $datlistfile ]
 then
  echo "File doesn't exist $datlistfile"
  exit
fi

python /data/soundscape/BirdNET-Analyzer/bnet_filelist.py --i $datlistfile --idir $datdir --overlap 1.5

