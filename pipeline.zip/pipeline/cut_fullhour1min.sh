#!/usr/bin/bash

LISTFILE=$1
datdir=$2
odatdir=$3

# column mdur not needed here if using following cmd (but note that then sdur must convert to integers...)
# sdur=$(ffprobe -i $origwavfile -show_entries format=duration -v quiet -of csv="p=0")

while read s3file mdur
do
  datfile=${s3file/s3:\//$datdir}  
  ./convertLifeplanFileFormat $datfile
  rm $datfile
  origwavfile=${datfile/.DAT/.WAV}
  dir=$(dirname $origwavfile)
  file=$(basename $origwavfile)
  base=${file/.DAT/}
  day=$(cut -f1 -d"_" <<< $base)
  time=$(cut -f2 -d"_" <<< $base)
  hour=${time:0:2}
  minute=${time:2:2}
  second=${time:4:2}
  # set start_time to nearest full hour
  start_time=$( perl nearest_full_hour.pl $time )
  # mdur is in minutes, sdur in seconds
  sdur=$(( $mdur * 60 ))
  # end_time not ok if start_time not zero, therefore set last_t1
  end_time=$(( $start_time + $sdur ))
  last_t1=$(( $sdur - 60 ))
  
  odir=${dir/$datdir/$odatdir}
  if [[ ! -d "$odir" ]]; then
      mkdir -p $odir
  fi

  echo ORIGWAV $origwavfile START $start_time END $end_time CUTDIR $odir
  for t1 in $(seq $start_time 3600 $end_time)	    
  do
   if [[ $t1 -lt $last_t1 ]]; then      
    # set outwav file name
    otime=$( perl otime.pl $time $t1 )
    owavfile=${odir}/${day}_${otime}.WAV
    # ignore first second and take following 59 seconds (to be similar with 1min record data)
    ss=$(( $t1 + 1))
    ffmpeg -loglevel error -nostdin -ss $ss -i $origwavfile -t 59 $owavfile
   fi 
  done
done < "$LISTFILE"
