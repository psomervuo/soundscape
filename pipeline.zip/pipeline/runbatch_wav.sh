#!/usr/bin/bash

index=$1
DATDIR=../data
DATLISTDIR=../datlists
OUTDIR=../out

bash step3_wav2acu.sh $DATLISTDIR/wbatch$index $DATDIR $OUTDIR/wbatch${index}.acu $OUTDIR/wbatch${index}.spec
bash step4_bird.sh $DATLISTDIR/wbatch$index $DATDIR $OUTDIR/wbatch${index}.bird
bash step5_yamnet.sh $DATLISTDIR/wbatch$index $DATDIR > $OUTDIR/wbatch${index}.yam

chmod a+rw $OUTDIR/wbatch${index}*
