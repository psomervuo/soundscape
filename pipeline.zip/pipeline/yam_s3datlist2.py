# Copyright 2019 The TensorFlow Authors All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

"""Inference demo for YAMNet."""
from __future__ import division, print_function

import sys

import numpy as np
import resampy
import soundfile as sf
import tensorflow as tf
import os

import params as yamnet_params
import yamnet as yamnet_model

# use only CPU because of problems with GPU...
os.environ['CUDA_VISIBLE_DEVICES'] = ''


def main(argv):
  assert argv, 'Usage: yam_wavlist_s3datlist.py listfile datdir'

  params = yamnet_params.Params()
  yamnet = yamnet_model.yamnet_frames_model(params)
  yamnet.load_weights('yamnet.h5')
  yamnet_classes = yamnet_model.class_names('yamnet_class_map.csv')

  listfile=argv[0]
  datdir=argv[1]

  spis = [];
  spis.append(np.argmax(yamnet_classes == 'Silence'))
  spis.append(np.argmax(yamnet_classes == 'Animal'))
  spis.append(np.argmax(yamnet_classes == 'Wind'))
  spis.append(np.argmax(yamnet_classes == 'Rain'))
  spis.append(np.argmax(yamnet_classes == 'Vehicle'))
  spis.append(np.argmax(yamnet_classes == 'Speech'))
  
  fin = open(listfile,"r")
  
  for line in fin:
    foo_name = line.strip()
    file_name = foo_name.replace("s3:/",datdir,1).replace(".DAT",".WAV")
    if os.path.exists(file_name) == False:
      print(file_name + '\tDOES_NOT_EXIST\t-1')
      continue
    # Decode the WAV file.
    wav_data, sr = sf.read(file_name, dtype=np.int16)
    if sr != 48000:
      print(file_name + '\tWRONG_SAMPLINGRATE\t-1')
      continue
    assert wav_data.dtype == np.int16, 'Bad sample type: %r' % wav_data.dtype
    waveform = wav_data / 32768.0  # Convert to [-1.0, +1.0]
    waveform = waveform.astype('float32')

    # Convert to mono and the sample rate expected by YAMNet.
    if len(waveform.shape) > 1:
      waveform = np.mean(waveform, axis=1)
    if sr != params.sample_rate:
      waveform = resampy.resample(waveform, sr, params.sample_rate)

    # Predict YAMNet classes.
    scores, embeddings, spectrogram = yamnet(waveform)

    nclasses = len(spis)
    spmax = np.zeros(nclasses)
    spmean = np.zeros(nclasses)

    # compute max and mean based on topn frames and report classes that exceed pth
    for i in range(nclasses):
      spmax[i] = np.max(scores[:,spis[i]])
      spmean[i] = np.mean(scores[:,spis[i]])

    print(file_name + ' ' + ' '.join('{:.3f} {:.3f}'.format(spmax[i], spmean[i]) for i in range(nclasses)))
    
  fin.close()   

if __name__ == '__main__':
  assert len(sys.argv) == 3, 'usage: yam_s3datlist.py listfile datdir'
  main(sys.argv[1:])
