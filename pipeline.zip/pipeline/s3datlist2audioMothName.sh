#!/usr/bin/bash

if [ ! $# -eq 2 ]
 then
  echo "usage: $0 datlistfile datdir"
  exit
fi

listfile=$1
datdir=$2

while read s3file
do
    datfile=${s3file/s3:\//$datdir}
    f=$(./audioMothName $datfile)
    echo $s3file $f
done < "$listfile"
