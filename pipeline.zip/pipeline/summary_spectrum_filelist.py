import librosa
import numpy as np
import sys
import os

def read_s3filelist(filename, datdir):
    a=[]
    with open(filename, 'r') as f:
        for line in f:
            s=line.strip()
            fname=s.replace("s3:/",datdir,1).replace(".DAT",".WAV")
            a.append(fname)
    return a

def read_listfile(ifile):
    filelist=[];
    with open(ifile,"r") as fin:
        for line in fin:
            if line.strip():
                filelist.append(line.strip())

    return filelist

def summary(audiofile, fmax=20000, fwidth=1000, fskip=100, tskip=0):
    """ calculate power spectrum with fwidth (Hz) bins upto fmax (Hz)
        skip first fskip Hz and skip first tskip (seconds) samples
        return max and mean values of bins in log10
    """
    sr=48000
    nfft=1024
    ind=[round(f/sr*nfft) for f in range(fskip,fmax+fwidth,fwidth)]
    eps=1e-5
    
    y,sr=librosa.load(audiofile,sr=sr, res_type='kaiser_fast')
    # skip first tskip seconds
    nskip = round(tskip*sr)
    S=np.abs(librosa.stft(y[nskip:], n_fft=nfft))**2
    Smax = np.max(S,axis=1)
    Smean = np.mean(S,axis=1)

    nbins=len(ind)-1
    bmax = np.zeros(nbins)
    bmean = np.zeros(nbins)
    
    for i in range(0,nbins):
        i1=ind[i]
        i2=ind[i+1]
        bmax[i] = 10*np.log10(np.sum(Smax[i1:i2]) + eps)
        bmean[i] = 10*np.log10(np.sum(Smean[i1:i2]) + eps)

    return bmax, bmean

def main(args):
    listfile=args[0]
    datdir=args[1]
    ifiles=read_s3filelist(listfile, datdir)
    for audiofile in ifiles:
        if os.path.isfile(audiofile):
            s1,s2 = summary(audiofile)
            t1= ' '.join(str(f'{x:.2f}') for x in s1)
            t2= ' '.join(str(f'{x:.2f}') for x in s2)
            print(f'{audiofile}\t{t1}\t{t2}')
            #print(f'{t1} {t2}')
    return

if __name__ == '__main__':
    main(sys.argv[1:])
    
