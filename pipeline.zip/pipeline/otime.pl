#!/usr/bin/perl

$start_hms=shift;
$seconds=shift;

$sh=substr($start_hms,0,2);
$sm=substr($start_hms,2,2);
$ss=substr($start_hms,4,2);

$seconds += 3600*$sh + 60*$sm + $ss;

$h=int($seconds / 3600);
$m=int(($seconds-3600*$h)/60);
$s=$seconds-3600*$h-60*$m;

$hms=sprintf("%02d%02d%02d",$h,$m,$s);
print "$hms\n";
