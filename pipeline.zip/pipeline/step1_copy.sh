#!/usr/bin/bash

listfile=$1
datdir=$2

while read datfile
do
  foo=$(dirname $datfile) 
  odir=${foo/s3:\//$datdir}
  if [[ ! -d "$odir" ]]; then
      mkdir -p $odir
  fi
  s3cmd get $datfile $odir
done < "$listfile"
