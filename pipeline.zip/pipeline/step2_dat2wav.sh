#!/usr/bin/bash

if [ $# -eq 0 ]
 then
  echo "usage: $0 datlistfile datdir"
  exit
fi

datlistfile=$1
datdir=$2

if [ ! -f $datlistfile ]
 then
  echo "File doesn't exist $datlistfile"
  exit
fi

# cut the first 1-second due to artefacts in some recordings

while read s3file
do
  datfile=${s3file/s3:\//$datdir}  
  ./convertLifeplanFileFormat $datfile
  wavfile=${datfile/DAT/WAV}
  owavfile=${datfile}.wav
  ffmpeg -loglevel error -nostdin -ss 00:00:01 -i $wavfile $owavfile
  mv $owavfile $wavfile
  rm $datfile  
done < $datlistfile  

