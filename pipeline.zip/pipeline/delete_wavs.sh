#!/usr/bin/bash

if [ $# -eq 0 ]
 then
  echo "usage: $0 datdir"
  exit
fi

datdir=$1

find $datdir -type f -name "*.WAV" -delete
