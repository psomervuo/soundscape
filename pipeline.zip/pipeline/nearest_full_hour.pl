#!/usr/bin/perl

$time=shift;
$hour=substr($time,0,2);
$minute=substr($time,2,2);
$second=substr($time,4,2);

$seconds = 60 * $minute + $second;
$skip=0;
if ($seconds > 0) {
  $skip = 3600 - $seconds;
}

print "$skip\n";
