#!/usr/bin/bash

source /data/lifeplan_analyze/venv/bin/activate

if [ $# -eq 0 ]
 then
  echo "usage: $0 datlistfile datdir out_acu out_spec"
  exit
fi

datlistfile=$1
datdir=$2
ofile1=$3
ofile2=$4

if [ ! -f $datlistfile ]
 then
  echo "File doesn't exist $datlistfile"
  exit
fi

python do_acu_filelist.py acuconfig.yaml $datlistfile $datdir $ofile1
python summary_spectrum_filelist.py $datlistfile $datdir > $ofile2
