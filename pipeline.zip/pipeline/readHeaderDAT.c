/****************************************************************************
 * convertLifeplanFileFormat.c
 * openacousticdevices.info
 * November 2020
 *****************************************************************************/

#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

/* File read constant */

#define FILE_BUFFER_SIZE                    128 * 1024 * 1024

#define FILENAME_BUFFER_SIZE                1024

#define FILE_EXTENSION_SIZE                 4

/* Sample constant */

#define NUMBER_OF_BYTES_IN_SAMPLE           2

/* WAV header constants */

#define PCM_FORMAT                          1
#define RIFF_ID_LENGTH                      4
#define LENGTH_OF_ARTIST                    32
#define LENGTH_OF_COMMENT                   384

/* Proprietary LIFEPLAN header constants */

#define PROP_FILE_HEADER_DESCRIPTOR_SIZE    8

#define PROP_FILE_OBSFUCATION_CODE          0b0101010101010101

/* Sample rate constants */

#define NUMBER_OF_SAMPLE_RATES              8

/* Useful macro */

#define MIN(a, b)                           ((a) < (b) ? (a) : (b))

#define ASSERT(condition, message) { \
    if (!(condition)) { \
        printf("ERROR: %s\n", message); \
        return 0; \
    } \
}

/* File reading and writing macros */

#define READ(dest, size, file) { \
    uint32_t bytesRead = fread(dest, 1, size, file); \
    ASSERT(bytesRead == size, "Unexpectedly reached end of input file."); \
}

#define WRITE(source, size, file) { \
    uint32_t bytesWritten = fwrite(source, 1, size, file); \
    ASSERT(bytesWritten == size, "Could not write output file."); \
}

/* File headers */

#pragma pack(push, 1)

/* WAV header */

typedef struct {
    char id[RIFF_ID_LENGTH];
    uint32_t size;
} chunk_t;

typedef struct {
    chunk_t icmt;
    char comment[LENGTH_OF_COMMENT];
} icmt_t;

typedef struct {
    chunk_t iart;
    char artist[LENGTH_OF_ARTIST];
} iart_t;

typedef struct {
    uint16_t format;
    uint16_t numberOfChannels;
    uint32_t samplesPerSecond;
    uint32_t bytesPerSecond;
    uint16_t bytesPerCapture;
    uint16_t bitsPerSample;
} wavFormat_t;

typedef struct {
    chunk_t riff;
    char format[RIFF_ID_LENGTH];
    chunk_t fmt;
    wavFormat_t wavFormat;
    chunk_t list;
    char info[RIFF_ID_LENGTH];
    icmt_t icmt;
    iart_t iart;
    chunk_t data;
} wavHeader_t;

/* Proprietary LIFEPLAN header */

typedef struct {
    char descriptor[PROP_FILE_HEADER_DESCRIPTOR_SIZE];
    uint32_t samplesPerSecond;
    char comment[LENGTH_OF_COMMENT];
    char artist[LENGTH_OF_ARTIST];
    uint32_t size;
} lifeplanHeader_t;

#pragma pack(pop)

/* Headers and buffers */

wavHeader_t wavHeader = {
    .riff = {.id = "RIFF", .size = 0},
    .format = "WAVE",
    .fmt = {.id = "fmt ", .size = sizeof(wavFormat_t)},
    .wavFormat = {.format = PCM_FORMAT, .numberOfChannels = 1, .samplesPerSecond = 0, .bytesPerSecond = 0, .bytesPerCapture = 2, .bitsPerSample = 16},
    .list = {.id = "LIST", .size = RIFF_ID_LENGTH + sizeof(icmt_t) + sizeof(iart_t)},
    .info = "INFO",
    .icmt = {.icmt.id = "ICMT", .icmt.size = LENGTH_OF_COMMENT, .comment = ""},
    .iart = {.iart.id = "IART", .iart.size = LENGTH_OF_ARTIST, .artist = ""},
    .data = {.id = "data", .size = 0}
};

lifeplanHeader_t lifeplanHeader;

char fileBuffer[FILE_BUFFER_SIZE];

char outputFileName[FILENAME_BUFFER_SIZE];

/* Deobsfucate data in proprietary file format */

static void deobsfucateDataForProprietaryFileFormat(int16_t *data, uint32_t length) {

    for (uint32_t i = 0; i < length; i += 1) {

        data[i] ^= PROP_FILE_OBSFUCATION_CODE;

    }

}

/* Valid sample rates */

uint32_t sampleRates[NUMBER_OF_SAMPLE_RATES] = {8000, 16000, 32000, 48000, 96000, 192000, 250000, 384000};

/* Code entry point */

int main(int argc, char *argv[]) {
    
    /* Check arguments */

    ASSERT(argc == 2, "Incorrect arguments supplied.");

    char *inputFileName = argv[1];

    /* Check the input filename */

    uint32_t inputFileNameLength = strlen(inputFileName);

    ASSERT(strcmp(inputFileName + inputFileNameLength - FILE_EXTENSION_SIZE, ".DAT") == 0, "Input file does not have a .DAT extension.");

    /* Open the input files */

    FILE *fi = fopen(inputFileName, "rb");

    ASSERT(fi != NULL, "Could not open the input file.");

    /* Read the LIFEPLAN header from the input file */

    READ(&lifeplanHeader, sizeof(lifeplanHeader_t), fi);

    /* Check the descriptor */

    ASSERT(strncmp(lifeplanHeader.descriptor, "LIFEPLAN", PROP_FILE_HEADER_DESCRIPTOR_SIZE) == 0, "Input file header ID does not match.");

    /* Check the sample rate */

    bool success = false;

    for (uint32_t i = 0; i < NUMBER_OF_SAMPLE_RATES; i += 1) {

        if (lifeplanHeader.samplesPerSecond == sampleRates[i]) success = true;

    }

    ASSERT(success, "Wrong sample rate.");

    /* Set the header parameters */
 
    wavHeader.wavFormat.samplesPerSecond = lifeplanHeader.samplesPerSecond;
    wavHeader.wavFormat.bytesPerSecond = NUMBER_OF_BYTES_IN_SAMPLE * lifeplanHeader.samplesPerSecond;
    wavHeader.data.size = lifeplanHeader.size - sizeof(wavHeader_t) + sizeof(lifeplanHeader_t);
    wavHeader.riff.size = wavHeader.data.size + sizeof(wavHeader_t) - sizeof(chunk_t);

    strncpy(wavHeader.icmt.comment, lifeplanHeader.comment, LENGTH_OF_COMMENT);

    strncpy(wavHeader.iart.artist, lifeplanHeader.artist, LENGTH_OF_ARTIST);

    /* Wind on input file */

    uint32_t result = fseek(fi, sizeof(wavHeader_t), SEEK_SET);

    ASSERT(result == 0, "Could read the input file.");

    uint32_t bytesLeftToCopy = wavHeader.data.size;

    /* Close file */

    ASSERT(fclose(fi) == 0, "Could not close the input file.");

    /* Finished */

    printf("file: '%s'\n",inputFileName);
    printf("samplesPerSecond: %d\n",lifeplanHeader.samplesPerSecond);
    printf("datasize: %d bytes\n",lifeplanHeader.size);
    printf("duration: %d seconds\n",lifeplanHeader.size / lifeplanHeader.samplesPerSecond / NUMBER_OF_BYTES_IN_SAMPLE);
    printf("comment: '%s'\n",wavHeader.icmt.comment);
    printf("artist: '%s'\n",wavHeader.iart.artist);

    return (0);
}
