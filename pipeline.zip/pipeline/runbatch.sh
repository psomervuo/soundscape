#!/usr/bin/bash

index=$1
DATDIR=../data
DATLISTDIR=../datlists
OUTDIR=../out

bash step1_copy.sh $DATLISTDIR/batch$index $DATDIR
bash s3datlist2audioMothName.sh $DATLISTDIR/batch$index $DATDIR > $OUTDIR/batch${index}.audiomoth
bash step2_dat2wav.sh $DATLISTDIR/batch$index $DATDIR
bash step3_wav2acu.sh $DATLISTDIR/batch$index $DATDIR $OUTDIR/batch${index}.acu $OUTDIR/batch${index}.spec
#bash step4_bird.sh $DATLISTDIR/batch$index $DATDIR $OUTDIR/batch${index}.bird
bash step4_birdnet.sh $DATLISTDIR/batch$index $DATDIR
bash step5_yamnet.sh $DATLISTDIR/batch$index $DATDIR > $OUTDIR/batch${index}.yam
bash step6_deletewavs.sh $DATLISTDIR/batch$index $DATDIR

#chmod a+rw $OUTDIR/batch${index}*
