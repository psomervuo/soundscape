#!/usr/bin/perl

# data in out/batchXXX.acu, out/batchXXX.spec, out/batchXXX.yam, out/batchXXX.audiomoth (and under data/... for Birdnet)

# perl spectrum2table.pl data/out 001 153 sitespectrum/spec

$idir = shift;
$index1 = shift;
$index2 = shift;
$odir = shift;

for ($index = $index1; $index <= $index2; $index++) {
    $filebase = sprintf("%s/batch%03d", $idir, $index);
    print "$filebase\n";
    
    $ifile = $filebase . '.yam';
    open(FD,$ifile) or die "ERROR: cannot read file '$ifile'";
    while (<FD>) {
	($wavfile, @a)=split;
	$wavfile =~ s/^..\/data\///;
	$wavfile =~ s/.WAV$//;
	@b=split(/\//,$wavfile);
	$id = (split(/-/,$b[0]))[1];
	push(@{$wavfiles{$id}}, $wavfile);
	
	$s = join(' ',@a);
	push(@{$data{$id}}, $s);
    }
    close(FD);
}

foreach $id (keys %wavfiles) {
    $ofile = sprintf("%s_%d",$odir,$id);
    open (OFD,">",$ofile) or die "ERROR: cannot write to '$ofile'. $!\n";
    @a = @{$wavfiles{$id}};
    @b = @{$data{$id}};
    $n = scalar(@a);
    for ($i=0; $i<$n; $i++) {
	print OFD "$a[$i] $b[$i]\n";
    }
    close(OFD);    
}
