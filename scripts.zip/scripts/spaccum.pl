#!/usr/bin/perl

# output time points where bnet results available (bnet result file can be also empty) from two sites
# ok if different years, but day and time must match
# perl spaccum.pl sitebnet_th/th8_666 sitebnet_th/th8_761 > naturb/th8_666_761

$file1=shift;
$file2=shift;

open(FD,$file1) or die "cannot read file1 '$file1'";
while (<FD>) {
    ($file,@a)=split;
    $n=scalar(@a)/2;
    $s= join(',',($n,@a));
    @b=split(/\//,$file);
    ($date,$time)=split(/_/,$b[$#b]);
    $year = substr($date,0,4);
    $month = substr($date,4,2);
    $day = substr($date,6,2);
    $key = "$month\t$day\t$time";
    $data1{$key} = $s;
}
close(FD);

open(FD,$file2) or die "cannot read file2 '$file2'";
while (<FD>) {
    ($file,@a)=split;
    $n=scalar(@a)/2;
    $s= join(',',($n,@a));
    @b=split(/\//,$file);
    ($date,$time)=split(/_/,$b[$#b]);
    $year = substr($date,0,4);
    $month = substr($date,4,2);
    $day = substr($date,6,2);
    $key = "$month\t$day\t$time";
    $data2{$key} = $s;
}
close(FD);

print "month\tday\ttime\tnatlist\turblist\n";
foreach $key (sort keys %data1) {
    if (exists($data2{$key})) {
	print "$key\t$data1{$key}\t$data2{$key}\n";
    }
}
