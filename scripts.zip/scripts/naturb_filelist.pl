#!/usr/bin/perl

$file=shift;
$basename=shift;

print "NATID\tURBID\tLAT\tLON\tFILE\tNATN\tURBN\tNATURBN\n";
open(FD,$file);
<FD>;
while (<FD>) {
    @a=split;
    $nat=$a[0];
    $urb=$a[12];
    $latlon = "$a[2]\t$a[3]";

    $ifile = $basename . "_$nat" . "_$urb" . ".nat";
    if (-e $ifile) {
	$n1=-1;
	open(FD2,$ifile) or die "ERROR: cannot read '$ifile'";
	while (<FD2>) {$n1++};
	close(FD2);
	
	$ifile = $basename . "_$nat" . "_$urb" . ".urb";    
	$n2=-1;
	open(FD2,$ifile) or die "ERROR: cannot read '$ifile'";
	while (<FD2>) {$n2++};
	close(FD2);
	
	$ifile = $basename . "_$nat" . "_$urb" . ".naturb";    
	$n3=-1;
	open(FD2,$ifile) or die "ERROR: cannot read '$ifile'";
	while (<FD2>) {$n3++};
	close(FD2);
	
	$file = $basename . "_$nat" . "_$urb";    
	print "$nat\t$urb\t$latlon\t$file\t$n1\t$n2\t$n3\n";
    }
}
close(FD);
