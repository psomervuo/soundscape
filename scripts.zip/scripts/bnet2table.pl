#!/usr/bin/perl

# perl bnet2table.pl BirdNET_GLOBAL_6K_V2.4_Labels.txt sitespecies/list_1001 ../acuindexdata/acudata sitelists/datlist_1001

$global_spfile=shift;
$site_spfile=shift;
$idir=shift;

open(FD,$global_spfile) or die "cannot read file '$global_spfile'";
$count=0;
while (<FD>) {
    s/\s+$//;
    ($sciname,$comname) = split(/_/,$_);
    $sp2index{$comname}=$count;
    $count++;
}
close(FD);

open(FD,$site_spfile) or die "cannot read file '$site_spfile'";
while (<FD>) {
    s/\s+$//;
    ($sciname,$comname) = split(/_/,$_);
    $okspecies{$comname}=1;
}
close(FD);

while (<>) {
    ($filebase) = split;
    $filename= $idir . '/' . $filebase . '.bnet';
    $th1=.3; 
    $th2=.8; 
    %count1=();
    %count2=();
    if (-e $filename) {
	open(FD,$filename) or die "cannot read file '$filename'";
	<FD>;
	while (<FD>) {
	    s/\s+$//;
	    @a=split(/\t/);
	    $sp=$a[8];
	    $conf=$a[9];
	    $count1{$sp}++ if ($conf > $th1);
	    $count2{$sp}++ if ($conf > $th2);
	}
	close(FD);
	print $filebase;
	foreach $sp (sort keys %count1) {
	    if ($okspecies{$sp}) {
		$flag=1;
	    } else {
		$flag=0;
	    }
	    $spindex = $sp2index{$sp};
	    $c1 = $count1{$sp};
	    if (exists($count2{$sp})) {
		$c2=$count2{$sp};
	    } else {
		$c2 = 0;
	    }
	    print " $spindex $flag $c1 $c2";
	}
	print "\n";
    } else {
	print STDERR "file '$filename' doesn't exist. skipping...\n";
    }
}
