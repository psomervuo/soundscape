#!/usr/bin/perl

# create species array to draw samples
# each input line is normalized to represent conditional probabilities
# final array is not normalized (divide by total sum of scores to get probabilities)

# input line
# num,spindex1,count1,...,spindex_num,count_num

$global_spfile=shift;
open(FD,$global_spfile) or die "cannot read file '$global_spfile'";
$count=0;
while (<FD>) {
    s/\s+$//;
    ($sciname,$comname) = split(/_/,$_);
    #$sp2index{$comname}=$count;
    $sciname =~ s/ /_/g;
    $comname =~ s/ /_/g;
    $index2sp{$count} = "$sciname\t$comname";
    $count++;
}
close(FD);

while (<>) {
    s/\s+$//;
    ($num,@a)=split(/,/);
    $n = scalar(@a);
    @rowsp = ();
    @rowcount = ();
    $rowsum = 0;
    for ($i=0; $i<$n; $i+=2) {
	$spindex = $a[$i];
	$count = $a[$i+1];
	push(@rowsp, $spindex);
	push(@rowcount, $count);
	$rowsum += $count;
    }
    if ($rowsum) {
	for ($i=0; $i<scalar(@rowsp); $i++) {
	    $score{$rowsp[$i]} += $rowcount[$i]/$rowsum;
	}
    }
}

print "speciesID\tscore\tsciname\tcomname\n";
foreach $sp (sort {$score{$b} <=> $score{$a}} keys %score) {
    print "$sp\t$score{$sp}\t$index2sp{$sp}\n";
}
