#!/usr/bin/perl

# perl select_naturb.pl 100 table_naturb.counts

$th=shift;

<>;
while (<>) {
      @a=split;
      $natSite = $a[0];
      $natName = $a[1];
      $natOkdays = $a[11];
      $urbSite = $a[12];
      $urbName = $a[13];
      $urbOkdays = $a[23];
      if (($natOkdays >= $th) and ($urbOkdays >= $th)) {
	  $ifile = "naturb/th8_" . $natSite . "_" . $urbSite;
	  $cmd = "cp $ifile naturb2";
	  system($cmd);

	  $ifile = "naturb/th8_" . $natSite . "_" . $urbSite . ".nat";
	  $cmd = "cp $ifile naturb2";
	  system($cmd);

      	  $ifile = "naturb/th8_" . $natSite . "_" . $urbSite . ".urb";
	  $cmd = "cp $ifile naturb2";
	  system($cmd);

	  $ifile = "naturb/th8_" . $natSite . "_" . $urbSite . ".naturb";
	  $cmd = "cp $ifile naturb2";
	  system($cmd);
      }
}
      

    
