#!/usr/bin/perl

# perl community_mean.pl spaccum_list2.naturb_avonet ../naturb2.list

$file=shift;
open(FD,$file);
$_=<FD>;
s/\s+$//;
@colnames=split(/\t/);
while (<FD>) {
    s/\s+$//;
    @a=split(/\t/);
    $spid = $a[0];
    @{$dat{$spid}} = @a;
}
close(FD);

@inds=(4,5,6,7,8,9,10,11,12,13,14);

while (<>) {
    ($filebase) = split;
    push(@filenames,$filebase);
    $natfile = "../" . $filebase . ".nat";
    $urbfile = "../" . $filebase . ".urb";
    foreach $ind (@inds) {
	$nat{$filebase}{$ind}=0;
	$urb{$filebase}{$ind}=0;
    }
    $natcount{$filebase}=0;
    $urbcount{$filebase}=0;
    open(FD,$natfile);
    <FD>;
    while (<FD>) {
	($spid,$score)=split;
	$natcount{$filebase} += $score;
	foreach $ind (@inds) {
	    $nat{$filebase}{$ind} += $score * ${$dat{$spid}}[$ind];
	}
    }
    close(FD);

    open(FD,$urbfile);
    <FD>;
    while (<FD>) {
	($spid,$score)=split;
	$urbcount{$filebase} += $score;
	foreach $ind (@inds) {
	    $urb{$filebase}{$ind} += $score * ${$dat{$spid}}[$ind];
	}
    }
    close(FD);
}

$ofile1="outcont.nat";
$ofile2="outcont.urb";

open(OFD,">",$ofile1);
$s = join("\t",@colnames[@inds]);
print OFD "$s\n";
foreach $filebase (@filenames) {
    @a=();
    foreach $ind (@inds) {
	push(@a,sprintf("%.3f",$nat{$filebase}{$ind}/$natcount{$filebase}));
    }
    $s = join("\t",@a);
    print OFD "$s\n";
}
close(OFD);

open(OFD,">",$ofile2);
$s = join("\t",@colnames[@inds]);
print OFD "$s\n";
foreach $filebase (@filenames) {
    @a=();
    foreach $ind (@inds) {
	push(@a,sprintf("%.3f",$urb{$filebase}{$ind}/$urbcount{$filebase}));
    }
    $s = join("\t",@a);
    print OFD "$s\n";
}
close(OFD);
