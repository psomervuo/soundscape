#!/usr/bin/perl

# speciesID	score	sciname	comname
# 4237	134.68966129791	Parus_major	Great_Tit

while (<>) {
    ($file)=split;
    push(@files,$file);
}

foreach $file (@files) {
    $sumscore1 = 0;
    %sc1 = ();
    open(FD,$file);
    <FD>;
    while (<FD>) {
	($id, $score, $sciname, $comname) = split;
	$sumscore1 += $score;
	$sc1{$id} = $score;
	$info{$id} = "$sciname\t$comname";
    }
    close(FD);
    if ($sumscore1 > 0) {
	foreach $id (keys %sc1) {
	    $totscore{$id} += $sc1{$id}/$sumscore1
	}
    }
}

print "speciesID\tscore\tsciname\tcomname\n";
foreach $id (sort {$totscore{$b} <=> $totscore{$a}} keys %totscore) {
    print "$id\t$totscore{$id}\t$info{$id}\n";
}
