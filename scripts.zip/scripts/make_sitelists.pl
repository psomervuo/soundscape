#!/usr/bin/perl

# data in out/batchXXX.acu, out/batchXXX.spec, out/batchXXX.yam, out/batchXXX.audiomoth (and under data/... for Birdnet)

# perl make_sitelists.pl data/out 001 153 sitelists/datlist

$idir = shift;
$index1 = shift;
$index2 = shift;
$odir = shift;

for ($index = $index1; $index <= $index2; $index++) {
    $filebase = sprintf("%s/batch%03d", $idir, $index);
    print "$filebase\n";
    %oksr = ();
    
    # check from .audiomoth that sampling rate is 48000

    $ifile = $filebase . '.audiomoth';
    open(FD,$ifile) or die "ERROR: cannot read file '$ifile'";
    while (<FD>) {
	($s3dat,$am,$device,$sr,$size) = split;
	$s3dat =~ s/^s3:\/\///;
	$s3dat =~ s/.DAT$//;
	if ($am eq 'AudioMoth') {
	    $oksr{$s3dat} = 1 if ($sr == 48000);
	}
    }
    close(FD);
    
    # check from .spec that file was processed
    
    $ifile = $filebase . '.spec';
    open(FD,$ifile) or die "ERROR: cannot read file '$ifile'";
    while (<FD>) {
	($wavfile)=split;
	$wavfile =~ s/^..\/data\///;
	$wavfile =~ s/.WAV$//;
	@a=split(/\//,$wavfile);
	$id = (split(/-/,$a[0]))[1];
	push(@{$wavfiles{$id}}, $wavfile) if ($oksr{$wavfile});
    }
    close(FD);
}

foreach $id (keys %wavfiles) {
    @b = sort {substr($a,-15) cmp substr($b,-15)} @{$wavfiles{$id}};
    $ofile = sprintf("%s_%d",$odir,$id);
    open (OFD,">",$ofile) or die "ERROR: cannot write to '$ofile'. $!\n";
    foreach $wavfile (@b) {
	@a=split(/\//,$wavfile);
	$lastitem = $a[$#a];
	print OFD "$wavfile\t$lastitem\n";
    }
    close(OFD);    
}
