#!/usr/bin/perl

# perl bnet2thlist.pl th BirdNET_GLOBAL_6K_V2.4_Labels.txt sitespecies/list_1001 ../acuindexdata/acudata sitelists/datlist_1001

$th=shift;
$global_spfile=shift;
$site_spfile=shift;
$idir=shift;

open(FD,$global_spfile) or die "cannot read file '$global_spfile'";
$count=0;
while (<FD>) {
    s/\s+$//;
    ($sciname,$comname) = split(/_/,$_);
    $sp2index{$comname}=$count;
    $count++;
}
close(FD);

open(FD,$site_spfile) or die "cannot read file '$site_spfile'";
while (<FD>) {
    s/\s+$//;
    ($sciname,$comname) = split(/_/,$_);
    $okspecies{$comname}=1;
}
close(FD);

while (<>) {
    ($filebase) = split;
    $filename= $idir . '/' . $filebase . '.bnet';
    %count=();
    if (-e $filename) {
	open(FD,$filename) or die "cannot read file '$filename'";
	<FD>;
	while (<FD>) {
	    s/\s+$//;
	    @a=split(/\t/);
	    $sp=$a[8];
	    $conf=$a[9];
	    $count{$sp}++ if ($conf > $th);
	}
	close(FD);
	print $filebase;
	foreach $sp (sort keys %count) {
	    if ($okspecies{$sp}) {
		$spindex = $sp2index{$sp};		
		print " $spindex $count{$sp}";
	    }
	}
	print "\n";
    } 
}
