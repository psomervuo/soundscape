#!/usr/bin/perl

while (<>) {
    ($file,@a)=split;
    $s11 = 0;
    $a11 = 0;
    $s12 = 0;
    $a12 = 0;
    $s01 = 0;
    $a01 = 0;
    $s02 = 0;
    $a02 = 0;
    for ($i=0; $i<scalar(@a); $i += 4) {
	$ind = $a[$i];
	$issitesp = $a[$i+1];
	$count1 = $a[$i+2];
	$count2 = $a[$i+3];
	if ($issitesp) {
	    $s11++;
	    $a11 += $count1;
	    if ($count2 > 0) {
		$s12++;
		$a12 += $count2;
	    }
	}
	$s01++;
	$a01 += $count1;
	if ($count2 > 0) {
	    $s02++;
	    $a02 += $count2;
	}
    }
    print "$file $s11 $a11 $s12 $a12 $s01 $a01 $s02 $a02\n";
}

