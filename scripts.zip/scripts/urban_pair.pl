#!/usr/bin/perl

while (<>) {
    @a=split;
    ($foo,$type) = split(/_/,$a[1]);
    if ($type eq "Natural") {
	@{$nat{$foo}} = @a;
    } elsif ($type eq "Urban") {
	@{$urb{$foo}} = @a;
    }
}

print "natSite natName natLAT natLON natType natTeam natHfi natElev natTemp natPrec natCounts natOkdays";
print " urbSite urbName urbLAT urbLON urbType urbTeam urbHfi urbElev urbTemp urbPrec urbCounts urbOkdays\n";

foreach $foo (sort keys %nat) {
    if (exists($urb{$foo})) {
	$s1=join(' ',@{$nat{$foo}});
	$s2=join(' ',@{$urb{$foo}});
	print "$s1 $s2\n";
    }
}
