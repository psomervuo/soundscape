#!/usr/bin/perl

# data in out/batchXXX.acu, out/batchXXX.spec, out/batchXXX.yam, out/batchXXX.audiomoth (and under data/... for Birdnet)

# perl acu2table.pl data/out 001 153 siteacu/acu

$idir = shift;
$index1 = shift;
$index2 = shift;
$odir = shift;

for ($index = $index1; $index <= $index2; $index++) {
    $filebase = sprintf("%s/batch%03d", $idir, $index);
    print "$filebase\n";

    # .acu has only last part of file name in result lists, take full names from .spec (filelist in same order)
    
    $ifile = $filebase . '.spec';
    open(FD,$ifile) or die "ERROR: cannot read file '$ifile'";
    @tmpids = ();
    while (<FD>) {
	($wavfile, @a)=split;
	$wavfile =~ s/^..\/data\///;
	$wavfile =~ s/.WAV$//;
	@b=split(/\//,$wavfile);
	$id = (split(/-/,$b[0]))[1];
	push(@{$wavfiles{$id}}, $wavfile);
	push(@tmpids,$id);
    }
    close(FD);

    $ifile = $filebase . '.acu';
    open(FD,$ifile) or die "ERROR: cannot read file '$ifile'";
    <FD>;
    $tmpi=0;
    while (<FD>) {
	s/\s+$//;
	($filename,$ACI,$ACImin,$ACImax,$ACImean,$ACImedian,$ACIstd,$ACIvar,$ADI,$Bio,$NDSI,$SE,$TE) = split(/,/);
	$H = $SE * $TE;
	$s = sprintf("%.3f %.3f %.3f %.3f %.3f",$ACI,$ADI,$Bio,$NDSI,$H);
	$id = $tmpids[$tmpi]; $tmpi++;
	push(@{$data{$id}}, $s);
    }
    close(FD);
    
}

foreach $id (keys %wavfiles) {
    $ofile = sprintf("%s_%d",$odir,$id);
    open (OFD,">",$ofile) or die "ERROR: cannot write to '$ofile'. $!\n";
    @a = @{$wavfiles{$id}};
    @b = @{$data{$id}};
    $n = scalar(@a);
    for ($i=0; $i<$n; $i++) {
	print OFD "$a[$i] $b[$i]\n";
    }
    close(OFD);    
}
