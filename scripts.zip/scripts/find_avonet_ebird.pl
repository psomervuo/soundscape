#!/usr/bin/perl

# perl find_avonet_ebird.pl AVONET_ebird.csv onurb

$file=shift;
open(FD,$file);
while (<FD>) {
    s/\s+$//;
    @a=split(/,/);
    $sci=$a[0];
    $sci =~ s/ /_/g;

    $beak_length_culmen = $a[9];
    $beak_length_nares = $a[10];
    $beak_width = $a[11];
    $beak_depth = $a[12];
    $tarsus_length = $a[13];
    $wing_length = $a[14];
    $kipps_distance = $a[15];
    $secondary1 = $a[16];
    $hand_wing_index = $a[17];
    $tail_length = $a[18];
    $mass = $a[19];
    
    $sci2dat_cont{$sci} = "$beak_length_culmen\t$beak_length_nares\t$beak_width\t$beak_depth\t$tarsus_length\t$wing_length\t$kipps_distance\t$secondary1\t$hand_wing_index\t$tail_length\t$mass";
    
    $habitat=$a[25];
    $habitat_density=$a[26];
    $migration=$a[27];
    $trophic_level=$a[28];
    $trophic_niche=$a[29];
    $primary_lifestyle=$a[30];
    
    $sci2dat_categ{$sci} = "$habitat\t$habitat_density\t$migration\t$trophic_level\t$trophic_niche\t$primary_lifestyle";
}
close(FD);

$_=<>;
s/\s+$//;
print $_;
print "\tbeak_length_culmen\tbeak_length_nares\tbeak_width\tbeak_depth\ttarsus_length\twing_length\tkipps_distance\tsecondary1\thand_wing_index\ttail_length\tmass";
print "\thabitat\thabitat_density\tmigration\ttrophic_level\ttrophic_niche\tprimary_lifestyle\n";
while (<>) {
    ($spid,$score,$sciname,$comname)=split;
    $dat1 = "NA";
    $dat2 = "NA";
    $dat1 = $sci2dat_cont{$sciname} if (exists($sci2dat_cont{$sciname}));
    $dat2 = $sci2dat_categ{$sciname} if (exists($sci2dat_categ{$sciname}));
    print "$spid\t$score\t$sciname\t$comname\t$dat1\t$dat2\n";
}
