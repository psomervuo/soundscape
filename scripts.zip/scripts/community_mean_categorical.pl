#!/usr/bin/perl

# perl community_mean.pl spaccum_list2.naturb_avonet ../naturb2.list

@inds=(15,16,17,18,19,20);

$file=shift;
open(FD,$file);
$_=<FD>;
s/\s+$//;
@colnames=split(/\t/);
while (<FD>) {
    s/\s+$//;
    @a=split(/\t/);
    $spid = $a[0];
    @{$dat{$spid}} = @a;
    foreach $ind (@inds) {
	$category = $a[$ind];
	$categories{$ind}{$category} = 1;
    }
}
close(FD);



while (<>) {
    ($filebase) = split;
    push(@filenames,$filebase);
    $natfile = "../" . $filebase . ".nat";
    $urbfile = "../" . $filebase . ".urb";
    foreach $ind (@inds) {
	foreach $category (keys %categories) {
	    $nat{$filebase}{$ind}{$category}=0;
	    $urb{$filebase}{$ind}{$category}=0;
	}
    }
    $natcount{$filebase}=0;
    $urbcount{$filebase}=0;
    open(FD,$natfile);
    <FD>;
    while (<FD>) {
	($spid,$score)=split;
	$natcount{$filebase} += $score;
	foreach $ind (@inds) {
	    $category = ${$dat{$spid}}[$ind];
	    $nat{$filebase}{$ind}{$category} += $score;
	}
    }
    close(FD);

    open(FD,$urbfile);
    <FD>;
    while (<FD>) {
	($spid,$score)=split;
	$urbcount{$filebase} += $score;
	foreach $ind (@inds) {
	    $category = ${$dat{$spid}}[$ind];
	    $urb{$filebase}{$ind}{$category} += $score;
	}
    }
    close(FD);
}

$ofile1="outcateg.nat";
$ofile2="outcateg.urb";

@a=();
foreach $ind (@inds) {
    foreach $category (sort keys %{$categories{$ind}}) {
	$s = $colnames[$ind] . ".$category";
	$s =~ s/\s//g;
	push(@a,$s);
    }
}
$header = join("\t",@a);

open(OFD,">",$ofile1);
print OFD "$header\n";
foreach $filebase (@filenames) {
    @a=();
    foreach $ind (@inds) {
	foreach $category (sort keys %{$categories{$ind}}) {
	    if (exists($nat{$filebase}{$ind}{$category})) {
		push(@a,sprintf("%.6f",$nat{$filebase}{$ind}{$category}/$natcount{$filebase}));
	    } else {
		push(@a,0);
	    }
	}
    }
    $s = join("\t",@a);
    print OFD "$s\n";
}
close(OFD);

open(OFD,">",$ofile2);
print OFD "$header\n";
foreach $filebase (@filenames) {
    @a=();
    foreach $ind (@inds) {
	foreach $category (sort keys %{$categories{$ind}}) {
	    if (exists($urb{$filebase}{$ind}{$category})) {
		push(@a,sprintf("%.6f",$urb{$filebase}{$ind}{$category}/$urbcount{$filebase}));
	    } else {
		push(@a,0);
	    }
	}
    }
    $s = join("\t",@a);
    print OFD "$s\n";
}
close(OFD);
