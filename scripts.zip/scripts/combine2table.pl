#!/usr/bin/perl

$site=shift;
$type=shift;
$lat=shift;
$lon=shift;

$info = "$site $type $lat $lon";

$header_info = "Site Type Latitude Longitude";
$header_spe = "SpecLowMax SpecMiddleMax SpecHighMax SpecLowMean SpecMiddleMean SpecHighMean";
$header_acu = "ACI ADI Bio NDSI H";
$header_yam = "SilenceMax SilenceMean AnimalMax AnimalMean WindMax WindMean RainMax RainMean VehicleMax VehicleMean SpeechMax SpeechMean";
#$header_bnet = "BnSiteSpecies1 BaSiteSpecies1 BnSiteSpecies2 BaSiteSpecies2 BnAllSpecies1 BaAllSpecies1 BnAllSpecies2 BaAllSpecies2";
$header_bnet = "BirdSpeciesNth1 BirdSpeciesAth1 BirdSpeciesNth2 BirdSpeciesAth2";

$datlist_file = "sitelists/datlist_${site}";
$spe_file = "sitespectrum/spec_${site}";
$acu_file = "siteacu/acu_${site}";
$yam_file = "siteyam/yam_${site}";
$bnet_file = "sitebnet2/bnet2_${site}";

open(FD,$datlist_file) or die "ERROR: cannot read '$datlist_file'.\n";
while (<FD>) {
    ($id)=split;
    $ok{$id}=1;
    push(@ids,$id);
}
close(FD);

open(FD,$spe_file) or die "ERROR: cannot read '$spe_file'.\n";
while (<FD>) {
    ($id, $x1, $x2, $x3, $x4, $x5, $x6)=split;
    $spe{$id} = "$x1 $x2 $x3 $x4 $x5 $x6";
}
close(FD);

open(FD,$acu_file) or die "ERROR: cannot read '$acu_file'.\n";
while (<FD>) {
    ($id, $x1, $x2, $x3, $x4, $x5)=split;
    if ($x1 eq "NaN") {
	$ok{$id} = 0;
    } 
    $acu{$id} = "$x1 $x2 $x3 $x4 $x5";
}
close(FD);

open(FD,$yam_file) or die "ERROR: cannot read '$yam_file'.\n";
while (<FD>) {
    ($id, $x1, $x2, $x3, $x4, $x5, $x6, $x7, $x8, $x9, $x10, $x11, $x12)=split;
    $yam{$id} = "$x1 $x2 $x3 $x4 $x5 $x6 $x7 $x8 $x9 $x10 $x11 $x12";
}
close(FD);

open(FD,$bnet_file) or die "ERROR: cannot read '$bnet_file'.\n";
while (<FD>) {
    ($id, $x1, $x2, $x3, $x4, $x5, $x6, $x7, $x8)=split;
    #    $bnet{$id} = "$x1 $x2 $x3 $x4 $x5 $x6 $x7 $x8";
    $bnet{$id} = "$x1 $x2 $x3 $x4";
}
close(FD);

print "$header_info Year Month Day Time $header_spe $header_acu $header_yam $header_bnet\n";
foreach $id (@ids) {
    if ($ok{$id} and exists($spe{$id}) and exists($acu{$id}) and exists($yam{$id}) and exists($bnet{$id})) {
	@a=split(/\//,$id);
	($foo,$time)=split(/_/,$a[$#a]);
	$year = substr($foo,0,4);
	$month = substr($foo,4,2);
	$day = substr($foo,6,2);
	print "$info $year $month $day $time $spe{$id} $acu{$id} $yam{$id} $bnet{$id}\n";
    }
}
