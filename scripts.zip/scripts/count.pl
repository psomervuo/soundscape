#!/usr/bin/perl

# perl count.pl table.txt sites_covs > sites.txt

$file=shift;
open(FD,$file);
<FD>;
while (<FD>) {
    ($Site, $Type, $Latitude, $Longitude, $Year, $Month, $Day, $Time) = split;
    $totcount{$Site}++;
    $key = "$Month $Day";
    $daycount{$Site}{$key}++;
}
close(FD);

$_=<>;
s/\s+$//;
print $_ . "\tcounts\tnum.ok.days\n";
while (<>) {
    ($Site)=split;
    s/\s+$//;
    if (!exists($daycount{$Site})) {
	$n1 = 0;
	$n2 = 0;
    } else {
	$n1 = $totcount{$Site};
	$n2 = scalar(keys %{$daycount{$Site}});
    }
    print $_ . "\t$n1\t$n2\n";
}


