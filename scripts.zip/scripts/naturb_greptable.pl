#!/usr/bin/perl

# perl naturb_greptable.pl sites_naturb table.txt

$file=shift;
open(FD,$file) or die "ERROR: cannot read file '$file'.";
while (<FD>) {
    ($natid,$natname,$natcount,$natdays,$urbid,$urbname,$urbcount,$urbdays)=split;
    $ifile = "naturb/th8_${natid}_${urbid}";
    open(FD2,$ifile) or die "ERROR: cannot read ifile '$ifile'";
    <FD2>;
    while (<FD2>) {
	($month,$day,$time)=split;
	$key = "$month $day $time";
	$ok{$natid}{$key}=1;
	$ok{$urbid}{$key}=1;	
    }
    close(FD2);
}
close(FD);

$_=<>;
print;
while (<>) {
    ($Site,$Type,$Latitude,$Longitude,$Year,$Month,$Day,$Time)=split;
    $key = "$Month $Day $Time";
    if ($ok{$Site}{$key} == 1) {
	print;
	$ok{$Site}{$key} = 2;
    }
}
