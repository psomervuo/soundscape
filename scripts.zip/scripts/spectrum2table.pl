#!/usr/bin/perl

# data in out/batchXXX.acu, out/batchXXX.spec, out/batchXXX.yam, out/batchXXX.audiomoth (and under data/... for Birdnet)

# perl spectrum2table.pl data/out 001 153 sitespectrum/spec

$idir = shift;
$index1 = shift;
$index2 = shift;
$odir = shift;

for ($index = $index1; $index <= $index2; $index++) {
    $filebase = sprintf("%s/batch%03d", $idir, $index);
    print "$filebase\n";
    
    $ifile = $filebase . '.spec';
    open(FD,$ifile) or die "ERROR: cannot read file '$ifile'";
    while (<FD>) {
	($wavfile, @a)=split;
	$wavfile =~ s/^..\/data\///;
	$wavfile =~ s/.WAV$//;
	@b=split(/\//,$wavfile);
	$id = (split(/-/,$b[0]))[1];
	push(@{$wavfiles{$id}}, $wavfile);
	
	$m1 = $a[0];
	$m2 = 0;
	$m3 = 0;
	$a1 = $a[20];
	$a2 = 0;
	$a3 = 0;
	for ($i=1; $i<=9; $i++) {
	    $m2 += 10**($a[$i]/10);
	    $a2 += 10**($a[$i+20]/10);
	}
	for ($i=10; $i<=19; $i++) {
	    $m3 += 10**($a[$i]/10);
	    $a3 += 10**($a[$i+20]/10);
	}
	$m2 = 10*log($m2)/log(10);
	$m3 = 10*log($m3)/log(10);
	$a2 = 10*log($a2)/log(10);
	$a3 = 10*log($a3)/log(10);
	$s = sprintf("%.3f %.3f %.3f %.3f %.3f %.3f",$m1,$m2,$m3,$a1,$a2,$a3);

	push(@{$data{$id}}, $s);
    }
    close(FD);
}

foreach $id (keys %wavfiles) {
    $ofile = sprintf("%s_%d",$odir,$id);
    open (OFD,">",$ofile) or die "ERROR: cannot write to '$ofile'. $!\n";
    @a = @{$wavfiles{$id}};
    @b = @{$data{$id}};
    $n = scalar(@a);
    for ($i=0; $i<$n; $i++) {
	print OFD "$a[$i] $b[$i]\n";
    }
    close(OFD);    
}
