#!/usr/bin/perl

<>;
while (<>) {
    @a=split;
    $id=$a[0];
    $b1=$a[31];
    $b2=$a[33];
    $count{$id}++;
    $n1{$id}++ if ($b1 > 0);
    $n2{$id}++ if ($b2 > 0);
}

foreach $id (sort {$a <=> $b} keys %count) {
    print "$id\t$count{$id}\t$n1{$id}\t$n2{$id}\n";
}
