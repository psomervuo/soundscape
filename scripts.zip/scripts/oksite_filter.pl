#!/usr/bin/perl

$okfile=shift;
open(FD,$okfile);
while (<FD>) {
    ($id) = split;
    $oksite{$id}=1;
}
close(FD);

$_=<>;
print;
while (<>) {
    ($id) = split;
    print if ($oksite{$id});
}

